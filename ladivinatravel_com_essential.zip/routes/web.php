<?php

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/intro', 'LandingpageController@index');
Route::get('/', 'HomeController@index');
Route::get('/home', 'HomeController@index')->name('home');
Route::post('/install/check-db', 'HomeController@checkConnectDatabase');

// Social Login
Route::get('social-login/{provider}', 'Auth\LoginController@socialLogin');
Route::get('social-callback/{provider}', 'Auth\LoginController@socialCallBack');

// Logs
Route::get(config('admin.admin_route_prefix') . '/logs', '\Rap2hpoutre\LaravelLogViewer\LogViewerController@index')->middleware(['auth', 'dashboard', 'system_log_view'])->name('admin.logs');

Route::get('/install', 'InstallerController@redirectToRequirement')->name('LaravelInstaller::welcome');
Route::get('/install/environment', 'InstallerController@redirectToWizard')->name('LaravelInstaller::environment');
Route::fallback([\Modules\Core\Controllers\FallbackController::class, 'FallBack']);


// Booking Module Routes
<?php

use Illuminate\Support\Facades\Route;

Route::middleware('web')->namespace('\\Pro\\Booking\\Controllers')->group(function () {
    Route::prefix('user/booking')->name('user.booking.')->middleware(['auth', 'pro_plan'])->group(function () {
        Route::get('{code}/ticket', 'TicketController@index')->name('ticket');
        Route::get('ticket/scan/{b}/{t}', 'TicketController@scan')->name('ticket.scan');
    });
});

// Support Module Routes
<?php
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Illuminate\Support\Facades\Route;

Route::prefix('support')->name('support.')->group(function () {
    Route::get('/', 'SupportController@index')->name('index');
    Route::prefix('topic')->name('topic.')->group(function () {
        Route::get('/', 'Topic\TopicController@index')->name('index');
        Route::get('{slug}', 'Topic\TopicController@detail')->name('detail');
        Route::get('cat/{slug}', 'Topic\CategoryController@index')->name('cat');
        Route::get('tag/{slug}', 'Topic\TagController@index')->name('tag');
    });
    Route::prefix('ticket')->name('ticket.')->middleware('auth')->group(function () {
        Route::get('/', 'Ticket\TicketController@index')->name('index');
        Route::get('/create', 'Ticket\TicketController@create')->name('create');
        Route::post('/store/{id?}', 'Ticket\TicketController@store')->name('store');
        Route::get('/detail/{id}', 'Ticket\TicketController@detail')->name('detail');

        Route::post('/reply_store/{id}', 'Ticket\TicketController@reply_store')->name('reply_store');
        Route::post('/action/{id}', 'Ticket\TicketController@action')->name('action');

    });
    Route::prefix('note')->middleware('auth')->name('note.')->group(function () {
        Route::post('/delete/{id}', 'NoteController@delete')->name('delete');
    });
});
