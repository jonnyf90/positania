<?php
// Admin Route
/*Route::group(['prefix'=>'admin','middleware' => ['auth','dashboard']], function() {
    Route::match(['get','post'],'/',function (){
        $module = ucfirst(htmlspecialchars('Dashboard'));
        $controller = ucfirst(htmlspecialchars($module));
        $class = "\\Modules\\$module\\Admin\\";
        $action = 'index';
        if(class_exists($class.$controller.'Controller') && method_exists($class.$controller.'Controller',$action)){
            return App::call($class.$controller.'Controller@'.$action,[]);
        }
        abort(404);
    });
    Route::match(['get','post'],'/module/{module}/{controller?}/{action?}/{param1?}/{param2?}/{param3?}',function ($module,$controller = '',$action = '',$param1 = '',$param2 = '',$param3 = ''){
        $module = ucfirst(htmlspecialchars($module));
        $controller = ucfirst(htmlspecialchars($controller));
        $class = "\\Modules\\$module\\Admin\\";
        if(!class_exists($class.$controller.'Controller')){
            $param3 = $param2;
            $param2 = $param1;
            $param1 = $action;
            $action = $controller;
            $controller = $module;
        }
        $action = $action ? $action : 'index';
        if(class_exists($class.$controller.'Controller') && method_exists($class.$controller.'Controller',$action)){
            $p = array_values(array_filter([$param1,$param2,$param3]));
            return App::call($class.$controller.'Controller@'.$action,$p);
//            return App::make($class.$controller.'Controller')->callAction($action,$p);
        }
        abort(404);
    });
});*/
// Support Module Admin Routes
<?php

use Illuminate\Support\Facades\Route;

Route::prefix('topic')->name('support.admin.topic.')->middleware(['pro_plan'])->group(function () {
    Route::get('/', 'Topic\TopicController@index')->name('index');
    Route::get('/edit/{id}', 'Topic\TopicController@edit')->name('edit');
    Route::get('/create', 'Topic\TopicController@create')->name('create');
    Route::get('/clone/{id}', 'Topic\TopicController@clone')->name('clone');
    Route::post('/store/{id}', 'Topic\TopicController@store')->name('store');
    Route::post('/bulkEdit', 'Topic\TopicController@bulkEdit')->name('bulkEdit');

    Route::get('/category', 'Topic\CategoryController@index')->name('category.index');

    Route::get('category/getForSelect2', 'Topic\CategoryController@getForSelect2')->name('category.getForSelect2');

    Route::get('/category/edit/{id}', 'Topic\CategoryController@edit')->name('category.edit');

    Route::post('/category/store/{id}', 'Topic\CategoryController@store')->name('category.store');
    Route::post('/category/bulkEdit', 'Topic\CategoryController@bulkEdit')->name('category.bulkEdit');

    Route::get('/tag', 'Topic\TagController@index')->name('tag.index');
    Route::get('/tag/edit/{id}', 'Topic\TagController@edit')->name('tag.edit');
    Route::post('/tag/store/{id}', 'Topic\TagController@store')->name('tag.store');
    Route::post('/tag/bulkEdit', 'Topic\TagController@bulkEdit')->name('tag.bulkEdit');
});
Route::prefix('ticket')->name('support.admin.ticket.')->middleware(['pro_plan'])->group(function () {
    Route::get('/', 'Ticket\TicketController@index')->name('index');
    Route::post('/bulkEdit', 'Ticket\TicketController@bulkEdit')->name('bulkEdit');

    Route::get('/category', 'Ticket\CategoryController@index')->name('category.index');
    Route::get('category/getForSelect2', 'Ticket\CategoryController@getForSelect2')->name('category.getForSelect2');
    Route::get('/category/edit/{id}', 'Ticket\CategoryController@edit')->name('category.edit');
    Route::post('/category/store/{id}', 'Ticket\CategoryController@store')->name('category.store');
    Route::post('/category/bulkEdit', 'Ticket\CategoryController@bulkEdit')->name('category.bulkEdit');
});
