<?php
return [
    'space_route_prefix' => env("SPACE_ROUTER_PREFIX","space"),
];