<?php
return [
    'event_route_prefix' => env("EVENT_ROUTER_PREFIX","event"),
];
