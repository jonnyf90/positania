<?php

return [
    'cores'=>[
        'core',
        'booking',
        'contact',
        'dashboard',
        'email',
        'language',
        'media',
        'news',
        'page',
        'theme',
        'user',
        'template',
        'report',
        'vendor'
    ],
    'active'=>[]
];
