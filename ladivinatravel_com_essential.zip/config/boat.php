<?php
return [
    'boat_route_prefix' => env("BOAT_ROUTER_PREFIX","boat"),
];